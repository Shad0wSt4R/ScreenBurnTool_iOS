//
//  ViewController.swift
//  Screen Burn Tool
//
//  Created by Marlena Hochmuth on 4/10/17.
//  Copyright © 2017 Marlena Hochmuth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK: properties

    @IBOutlet weak var imageViewer: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //let width = UIScreen.mainScreen().bounds.size.width
        //let height = UIScreen.mainScreen().bounds.size.height
        
        //imageViewer = UIImageView(frame: CGRectMake(0, 0, width, height))
        
        imageViewer.animationImages = [
            UIImage(named: "red.png")!,
            UIImage(named: "green.png")!,
            UIImage(named: "blue.png")!,
            UIImage(named: "white.png")!,
            UIImage(named: "black.png")!]
        imageViewer.contentMode = UIViewContentMode.scaleAspectFill
        imageViewer.animationDuration = 0.5
        imageViewer.startAnimating()
    }

    /*override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }*/


}

